These files record the guidance given to Scarlets and Blues volunteers, comprising the Field Guide, the Tutorials and per-task Help.

Screenshots of course only capture the instructions at a given point in time. It is possible that instructions are added, removed or changed as a project runs. These screenshots were taken after the project's completion.

Screenshots are also captured on particular web browsers at particular window sizes and with a particular stack of underlying technology. Changes in any of these factors may make the instructions appear different.
