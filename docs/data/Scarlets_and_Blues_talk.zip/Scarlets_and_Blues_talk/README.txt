These files are exports of the content of the project's Talk pages. They
provide a record of comments made by volunteers and by members of the project
team, and of tags that were applied to particular records.

File                                     Generated At       Description
----                                     ------------       -----------
project-12268-comments_2022-12-12.json   2022-12-12 12:18   All comments on the project's Talk pages
project-12268-tags_2022-12-12.json       2022-12-12 12:18   All tags applied to subjects (records) by volunteers

All "Generated At" dates/times are in UTC, and in "YYYY-MM-DD HH-MM" format.
For example, 10:37 PM on the 14th of January 2022 would be written as
2022-14-01 22:37.
