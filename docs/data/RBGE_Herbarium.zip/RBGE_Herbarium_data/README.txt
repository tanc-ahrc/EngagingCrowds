About This Data
===============

This data describes the individual classifications made by volunteers in this Zooniverse
project. It is provided as a Comma Separated Values (CSV) file. The easiest way to view the
data is to open it in standard spreadsheet software such as Excel, Numbers or Google sheets.
This will show the data as a table, with column headings at the top. These column headings
label the 'fields' making up the data. A field is a single entity in the data, such as a user
name or the time at which a classification was completed. Each row in the table gives
information about a single classification of a single record by a single volunteer.

The complete list of fields that we provide is:

classification_id            Unique identifier for the classification
workflow_id                  Unique identifier for the workflow within which the classification was made
workflow_name                The human-readable name of the workflow within which the classification was made
workflow_version             The version of the workflow within which the classification was made
created_at                   The server-side date/time that the classification was made
annotations                  The volunteer's transcription of the record. This is a JSON structure recording the volunteer's path
                             through the whole workflow for this record. Forthcoming scripts will reconcile these transcriptions
                             into a convenient form to describe the records.
subject_ids                  Unique identifier of the subject to which the classification applied.
                             There is only ever 1 subject id per classification in the Engaging Crowds projects.
subj.#priority               Number used by the indexer to order the subjects.
subj.retired.retired_at      UTC date/time that the subject acquired enough classifications to be considered complete.
subj.id                      Unique identifier for the specimen
subj.botanist                The botanist who collected the specimen
subj.group                   The geographical region that the specimen was collected from
subj.image                   Filename of the image
subj.format                  The format of the record itself (either 'herbarium sheet' or 'herbarium specimen')
subj.species                 The species of the specimen
subj.barcode                 Barcode used to identify the specimen
pseudonym                    Pseudonym for the user who made the classification. Pseudonyms are consistent across all three projects.
                             A pseudonym beginning 'user': indicates a logged-in user. A pseudonym beginning 'anon:' indicates an
                             anonymous user, identified by a hash of their IP address. This should be treated as a much less reliable
                             identification than a user login.
md.started_at                Client-side UTC start date/time of classification
md.finished_at               Client-side UTC finish date/time of classification
md.utc_offset                Offset from client's local time to UTC (subtract utc_offset to convert to local time)
location.rbge                Citable location of the classified file on the RBGE website
location.zooniverse.project  Location of the subject in the project's index
location.zooniverse.plain    Location of the subject image on the Zooniverse servers


Alterations to the Original Data
================================

The original Zooniverse data export contains two metadata columns: record metadata, describing
the record being classified, and classification metadata, describing the act of classification.
Each row in these metadata columns contains multiple fields which we 'flatten' into
new columns. Record metadata fields are prefixed with 'subj.' Classification metadata
fields are prefixed with 'md.'

Classification metadata is provided by the Zooniverse platform. Some record metadata is
provided by the Zooniverse platform and some is provided by project administrators. We keep
all of the metadata that comes from the project administrators but discard most of the metadata
that comes from the platform. The following platform-provided metadata fields are useful for
our engagment analysis and so are kept:
  * subj.retired.retired_at
  * md.started_at
  * md.finished_at
  * md.utc_offset

Metadata field names in mixed case are all treated as being the same field, as are field names
differing only by the presence or absence of a single '#' character. Field names are all presented in
lower case in this CSV file.

All other data from the Zooniverse data export is included here, but user names have been replaced
by pseudonyms.


Information on Reuse
====================
These images are licensed according to the CC BY 4.0 licence (https://creativecommons.org/licenses/by/4.0/). This licence allows people to freely use images as long as they give appropriate credit and indicate if any changes have been made.

The data transcribed by volunteers is licensed according to the CC0 licence (https://creativecommons.org/share-your-work/public-domain/cc0). This licence means there are no copyright restrictions on this data and it can be freely reused.


Citation Information
====================

Any use of the images or data from The RBGE Herbarium should credit 'Royal Botanic Garden Edinburgh' as the source.


Reproduction
============

Reproduction of this data requires access to the original classifications, which is limited to the project team.
However, the reproduction recipe is:
* git clone https://github.com/nationalarchives/engaging_crowds_user_analysis.git
* cd engaging_crowds_user_analysis
* git checkout 8e3b746e81d6b1b8f9692be5b18be34b5f25cd15 #Optional, to use the scripts at the point when this bundle was generated
* pip install -r requirements.txt #You might prefer to do this in a virtualenv
* (Download the original project export files from the relevant Engaging Crowds project(s) to engaging_crowds_user_analysis/exports/)
* ./pseudonymise.py

The output will appear in the sharing/ directory.

Note that the generated output might not be exactly identical to the files on the website. This is because changes in the
uploaded subjects can mean that URLs giving the location of the original subject can appear and disappear (and perhaps even
be incorrect).

Pseudonyms are randomly generated so will differ from run to run. They are unique per user-id.


This bundle generated from git state 8e3b746e81d6b1b8f9692be5b18be34b5f25cd15 ## main...origin/main
